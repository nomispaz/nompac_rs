package labels

func main() {
	code()
Label:
	code()
Label2:
	code()
Label3: // Comments!
	code()

	for {
	Label4:
		// code
	}

	{
	Label5:
	}
}
