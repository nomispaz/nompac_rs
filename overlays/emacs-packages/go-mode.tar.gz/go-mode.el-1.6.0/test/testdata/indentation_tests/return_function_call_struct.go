package main

func main() {
	return F(
		S{
			1,
			2,
			3,
		},
	)
}
