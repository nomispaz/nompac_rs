# v1.0.6

- Add support for treesitter mode.
- Fix warnings resulting from rust-utils.el. [Fixes #509](https://github.com/rust-lang/rust-mode/issues/509).
- Fix tree sitter mode with hooks integraiton. [Fixes #516](https://github.com/rust-lang/rust-mode/issues/516).
