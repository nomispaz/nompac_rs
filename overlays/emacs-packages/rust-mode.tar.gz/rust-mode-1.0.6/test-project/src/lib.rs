pub fn test_project() {
    // This is only present, because cargo locate-project --workspace actually
    // validates the rust project and fails if there is no target.
}
